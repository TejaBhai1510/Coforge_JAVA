export const INCREMENET = "counter/increment";
export const DECREMENT = "counter/decrement";