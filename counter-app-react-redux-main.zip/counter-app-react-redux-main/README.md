# counter-app-react-redux
![counter-app-react-redux](/src/assets/github-cover.png)
